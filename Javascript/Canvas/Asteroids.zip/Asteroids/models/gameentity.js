import Entity from '../libs/entity.js';
export default class GameEntity extends Entity {
    constructor(form, body) {
        super(form, body)
        this.removing = false;
    }
}

// alive() {
//     this.life.
// }
// die() {
//     this.life.value = 0;
// }
// spawn() {
//     this.life.value = this.life.max;
// }
