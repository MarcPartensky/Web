interface Anatomy {
    // constructor: func;
    // contains: func;
    // rotate: func;
    // move: func;
    lineWidth: number;
    str: string;
}